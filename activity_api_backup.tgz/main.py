from contextlib import asynccontextmanager
import sqlite3
from fastapi import FastAPI
from fastapi.responses import RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware

from db import (
    init_db_if_not_exists,
    insert_person_families,
    insert_picture_activities,
    insert_activities_days,
)

from routers.home import router as home_router
from routers.activity import router as activity_router
from routers.mainmenu import router as mainmenu_router
from routers.livenow import router as livenow_router
from routers.pictureactivity import router as pictureactivity_router
from routers.persons import router as persons_router
from routers.stats import router as stats_router
from routers.api_activity import router as api_activity_router
from routers.api_live import router as api_live_router
from routers.api_persons import router as api_persons_router
from routers.api_pictureactivities import router as api_pictureactivities_router
from fastapi.middleware.cors import CORSMiddleware


# =========================
# LIFESPAN (startup/shutdown)
# =========================
DB_PATH = Path(__file__).parent / "activity.db"


@asynccontextmanager
async def lifespan(app: FastAPI):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:
        # konfiguracja bazy RAZ na start
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout = 5000;")

        init_db_if_not_exists(conn)
        insert_person_families(conn)
        insert_picture_activities(conn)
        insert_activities_days(conn)

        conn.commit()
        conn.close()

        yield

    finally:
        conn.close()


# =========================
# FASTAPI
# =========================
app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost",
        "https://localhost",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# STATIC
# =========================
STATIC_DIR = Path(__file__).parent / "static"

app.mount(
    "/static",
    StaticFiles(directory=STATIC_DIR),
    name="static"
)


# ---------- MAIN PAGE ----------
REACT_DIR = STATIC_DIR / "react"

if (REACT_DIR / "index.html").exists():
    app.mount("/assets", StaticFiles(directory=REACT_DIR / "assets"), name="react-assets")

    @app.get("/favicon.svg")
    def react_favicon():
        return FileResponse(REACT_DIR / "favicon.svg")

    @app.get("/")
    def react_index():
        return FileResponse(
            REACT_DIR / "index.html",
            headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
        )
else:
    @app.get("/")
    def root_redirect():
        return RedirectResponse("/live/statusall", status_code=302)


# ---------- ROUTERS ----------
app.include_router(home_router)
app.include_router(mainmenu_router)
app.include_router(activity_router)
app.include_router(livenow_router)
app.include_router(pictureactivity_router)
app.include_router(persons_router)
app.include_router(stats_router)
app.include_router(api_activity_router)
app.include_router(api_live_router)
app.include_router(api_persons_router)
app.include_router(api_pictureactivities_router)


